
const createTask = (e) =>{
    e.preventDefault()
    let todos = [];
    let task = {
        name: document.getElementById('taskName').value,
        startDate: document.getElementById('startDate').value,
        endDate: document.getElementById('endDate').value,
        taskDescription: document.getElementById('taskDescription').value,
        isCompleted: false
    }
    todos.push(task)
    //document.querySelector('form').reset()

    // for writing to local storage
    localStorage.setItem('MyTasks', JSON.stringify(todos))
}

const submitButton = document.querySelector('#submitBtn')
submitButton.addEventListener('click', createTask)

